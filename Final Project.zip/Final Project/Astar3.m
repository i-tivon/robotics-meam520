function [path] = Astar2(map, start, goal, robot)
% ASTAR Find the shortest path from start to goal.
%   PATH = ASTAR(map, start, goal) returns an mx6 matrix, where each row
%   consists of the configuration of the Lynx at a point on the path. The 
%   first row is start and the last row is goal. If no path is found, PATH 
%   is a 0x6 matrix. Consecutive points in PATH should not be farther apart
%   than neighboring voxels in the map (e.g. if 5 consecutive points in 
%   PATH are co-linear, don't simplify PATH by removing the 3 intermediate points).
% 
%   PATH = ASTAR(map, start, goal) finds the path using euclidean
%   distance to goal as a heuristic.
%
%   [PATH, NUM_EXPANDED] = ASTAR(...) returns the path as well as
%   the number of nodes that were expanded while performing the search.
%   
% INPUTS:
%   map     - the map object to plan in (cartesian map)
%   start   - 1x6 vector of the starting configuration
%   goal:   - 1x6 vector of the goal configuration

%make class for "node"
%node
%   configuration
%   parent
%   H-heuristic (euclidean distance to goal)
%   G-graph cost


%(THIS ISN'T NECESSARY)
%make class called "config"
%config
%   defines joint values 
%   (start with first 3 joints and do more if it's working)

%INPUTS: start, goal, map robot

%define startNode = node(config(start))
%define goalNode = node(config(goal))
startNode=node;
startNode.conf=start;
goalNode=node;
goalNode.conf=goal;

%Lists
%openSet - total neighbors
%closedSet - already checked neighbors
openSet=[];
closedSet=[];

%disp("initialized nodes and sets");
%define G and H for snartNode and goalNode
%   startNode.G=0
%   startNode.H=euclid dist to goal
startNode.G=0;
startNode.H=euclid(startNode,goalNode);

%currentNode
%   initially set to startNode
%   add to openSet
currentNode=startNode;
openSet=[openSet currentNode];

%function for euclidean distance between configs
%   use FK

%while = still neighbors in openSet
%   update currentNode = min(openSet)
%       min of G+H values of neighbors
%   if currentNode=goalNode
%       empty path
%       work backwards through the parents to startNode
%       add the parents to the path
%       return = path

%function "checkpoints"
%   check that configurations are "equal" (withing some range)

%define STEP
%   -1, 0, 1

%function "getNeighbors"
%   (gets the neighbors of currentNode)
%   INPUTS: currentNode, pre-set STEP array
%   use FK to get x,y,z of EE of currentNode
%   look at the neighbors using the STEP array, all combos
%   check:
%       1. collisions b/t currentNode and neighbNode
%       2. not an obstacle
%              if all conditions asatisfied
%                   return neighbors (list of neighbors)


%in main code:
%take currentNode from openSet, move to closedSet
%find neighbors ("getNeighbors")
%for each neighbor
%   if in closedSet
        %ignore - DO NOTHING
%   else (it is untouched)
        %find tentativeG (=currentNode.G+(dist(curr to neighb)) **NEED A FUNCTION**
%       if openSet = empty (we are in startNode)
%           neighb.G=tentativeG
%           neighb.H (euclidean distance from curr EE to goal EE)
%           neighb.parent = currentNode
%           add to openSet
%       else (looking at an actual neighbor)           
%           if not in openSet

res=0.1;

while ~isempty(openSet)
    [currentNode,ind]=minNeighb(openSet);
    disp(currentNode.conf);
    %disp("got current node");
%     if currentNode.conf == goalNode.conf
%         disp("stop")
%         while 1
%         end
%     end
%     disp(checkNode(currentNode, goalNode));
%     disp("goal is");
%     disp(goalNode.conf);
    if checkNode(currentNode, goalNode) %HI THERE
        disp("reached goal");

        %might need within range function
        path=[];
        disp("adding to path");
        while ~checkNode(currentNode, startNode) %HI THERE
            disp(currentNode.conf);
            disp("check here");
            path=[currentNode.conf;path];
            currentNode=currentNode.parent;
        end
        path=[startNode.conf;path];
        break  
    end
    
    
    
    openSet(ind)=[];
    closedSet=[closedSet,currentNode];
    neighb=getNeighbors(currentNode,res,map,robot);
    %disp("got neighbors");
    s=length(neighb);
    for i=1:s
        if ~isMembNode(neighb(i),closedSet)
            %disp("filling neighbors");
            tentG=currentNode.G+1;
            neighb(i).G=tentG;
            neighb(i).H=euclid(neighb(i),goalNode);
            openSet=[neighb(i),openSet];
%             if isempty(openSet)
%                 neighb(i).G=tentG;
%                 neighb(i).H=euclid(neighb(i),goalNode);
%                 openSet=[neighb(i),openSet];
%             else
%                 if ~ismember(neighb(i),openSet)
%                     neighb(i).H=euclid(neighb(i),goalNode);
%                     if tentG<
        end 
    end
    
    
    
    
    
end



disp("path is:");
disp(path);
end

