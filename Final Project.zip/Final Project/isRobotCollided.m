function [isCollided] = isRobotCollided(q, map, robot)
% ISROBOTCOLLIDED Detect if a configuration of the Lynx is in collision
%   with any obstacles on the map.
%
% INPUTS:
%   q   - a 1x6 configuration of the robot
%   map - a map strucutre containing axis-aligned-boundary-box obstacles
%   robot - a structure containing the robot dimensions and joint limits
%
% OUTPUTS:
%   isCollided - a boolean flag: 1 if the robot is in collision, 0 if not.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                  Algortihm Starts Here             %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Account for the geometry of the object: When analyzing each joint, consider the
% servo motor as a circle and expand the obstacle by the radius of that circle.
% Consider each link as a thin cylinder so when analyzing collision with a link,
% expand the obstacle by the radius of the thin cylinder.
% 
% detectcollision.p: Detects collision between a line segment and a rectangular prism. Usage:
% iscollided = detectcollision(linePt1, linePt2, box), where linePt1 and linePt2 are
% N 3 arrays, with each row [x; y; z] being the start/end locations of the line segment, and box is
% an array of the form
% [xmin,ymin,zmin,xmax,ymax,zmax]. Returns a boolean iscollided, which is true if the line
% segment intersects with the box and false otherwise. Keep in mind that this assumes a line of
% zero thickness.
%  detectcollision.p is vectorized to accept any number of line segments, but only one box
% per call. If you call it with multiple lines, iscollided will be row-aligned with the line
% segments
load 'robot.mat' robot
stop =0;
isCollided = 0;

%first do FK for q
[jointPositions,~] = calculateFK_sol(q);
%jointPositions - 6 x 3 matrix

%servo radius size in mm


%servo
%radius = 101.6; %mm
radius=1;
%link
%radius2 =  50.8; %mm
radius2=1;

%loop through each joint/link
%consider joints as points and links as lines btw joints
obstacles = map.obstacles;
for r = 1:6
        if stop == 1
            break;
        else
        jointPos = jointPositions(r,:);

        %loop through each obstacle
        s = size(map.obstacles);
        for o = 1:s
            if stop == 1
                break;
            else
                
            obs = obstacles(o,:); 
            xmin = obs(1);
            ymin = obs(2);
            zmin = obs(3);
            xmax = obs(4);
            ymax = obs(5);
            zmax = obs(6);
            %check joint
            %consider joint as point
            %expand obstacle by servo radius size
            xminO = xmin - radius;
            yminO = ymin - radius;
            xmaxO = xmax + radius;
            ymaxO = ymax + radius;
            zminO = zmin - radius;
            zmaxO = zmax + radius;
            
            
            %check if point is in any obstacle rectangle
            x = jointPos(1);
            y = jointPos(2);
            z = jointPos(3);
            if x>xminO && x<xmaxO && y>yminO && y<ymaxO && z>zminO && z<zmaxO 
                isCollided = 1; %if true, return 1
                stop = 1;
                break;
            end
            
           
            %if joint 7, break
            if r == 6
                break;
            else
                %check link to next joint
                %expand obstacle by radius size %cylinder around link
                xminL = xmin - radius2;
                yminL = ymin - radius2;
                xmaxL = xmax + radius2;
                ymaxL = ymax + radius2;
                zminL = zmin - radius2;
                zmaxL = zmax + radius2;
                onew = [xminL,yminL,zminL,xmaxL,ymaxL,zmaxL];

                c = detectCollision(jointPos, jointPositions(r+1,:), onew);

                %if true, return 1
                isCollided = isCollided | c;
                if isCollided == 1
                    stop = 1;
                    break;
                end
            end
            end
        end
        end
end
 
    

    



    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                  Algortihm Ends Here               %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end