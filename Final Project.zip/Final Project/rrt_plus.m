function [path] = rrt_plus(map, start, goal)
% RRT Find the shortest path from start to goal.
%   PATH = rrt(map, start, goal) returns an mx6 matrix, where each row
%   consists of the configuration of the Lynx at a point on the path. The 
%   first row is start and the last row is goal. If no path is found, PATH 
%   is a 0x6 matrix. 
%
% INPUTS:
%   map     - the map object to plan in
%   start   - 1x6 vector of the starting configuration
%   goal:   - 1x6 vector of the goal configuration


%% Prep Code

path = [];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                  Algortihm Starts Here             %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pathGoal = [];
load 'robot.mat' robot
%define beginning configuration and end goal
%initally not connected to anything
%0 represents the final C in that path
% Tstart= (qstart, �), Tgoal= (qgoal, �)
path = [path; start];
pathGoal = [pathGoal; goal];


K = 20000000;
%for loop!
for k = 1:K
   
    
    % q = random configuration in Qfree
    %consider joint limits? 
    
    w = 0;
    while w == 0
        q1 = (1.4+1.4)*rand-1.4;
        q2 = (1.4+1.2)*rand-1.2;
        q3 = (1.7+1.8)*rand -1.8;
        q4 = (1.7+1.9)*rand - 1.9;
        q5 = (1.5+2) *rand - 2;
        q6 = (30+15)*rand-15;
        q =[q1 q2 q3 q4 q5 q6];
        b = isRobotCollided(q, map, robot);
        %making sure q is valid
        if b == 0
            w = 1;
        end
    end
            
    
    % qa= closest node in Tstart
    %last row of path
    l = size(path);
    qa = path(l(1),:);
    % if Snext = 0, qa = qstart
    % else qa = Snext (next updates each loop with closest node in Tstart)
    
    %linear interpolation
    % IfNOT collide(qqa)
    %check for collision
    [linePt1,~] = calculateFK_sol(q);
    [linePt2,~] = calculateFK_sol(qa);
    obstacles = map.obstacles;
    s = size(map.obstacles);
    qqaCollide = 0;
    for o = 1:s
        c = detectCollision(linePt1, linePt2,obstacles(o,:));

        qqaCollide = qqaCollide | any(c);  
    end
    if qqaCollide == 0
        % Add (q,qa) to Tstart
        path = [path; q] ;
        % update Snext with q
        %add q to overall path
    end
        
        
    % qb= closest node in Tgoal
    % if Gnext = 0, qb = qgoal
    % else qb = Gnext (next updates each loop with closest node in Tgoal)
    
    % IfNOT collide(qqb)
    %check for collision
        % Add (q,qb) to Tgoal
        % update Gnext with q
        
    qb = pathGoal(1,:);
    
    %linear interpolation
    % IfNOT collide(qqa)
    %check for collision
    [linePt3,~] = calculateFK_sol(qb);
    
    qqbCollide = 0;
    for o = 1:s
        c = detectCollision(linePt1, linePt3,obstacles(o,:));
        qqbCollide = qqbCollide | any(c)  ;
    end
    if qqbCollide == 0
        % If q connected to Tstart and Tgoal
        if qqaCollide == 0 & qqbCollide == 0
            path = [path;pathGoal];
%             disp(path);
            break;
        else
        
        pathGoal = [q; pathGoal] ;
        end
        
        
    end
    
        
    
     %else if  %"no path" if k=K
    if k == K
        disp("No path found")
        
    end
end
disp("post processing")
%post-processing

for i = 1:(size(path,1)-2) 
    p = 0;
    while p == 0
        disp(path)
        if size(path,1) <3
            p=1;
        else
        nodeA = path(i,:);
        nodeB = path(i+2,:);
        %FK
        [linePtA,~] = calculateFK_sol(nodeA);
        [linePtB,~] = calculateFK_sol(nodeB);
        %check collision for all obstacles
        obstacles = map.obstacles;
        s = size(map.obstacles);
        qCollide = 0;
        for o = 1:s
            c = detectCollision(linePtA, linePtB,obstacles(o,:));
            qCollide = qCollide | any(c);  
        end
        %if not collided, remove node in between and redo while loop
        if qCollide == 0
            path(i+1,:) = [];
           
        else
            p=1;
        end
        end
    end
end
% disp(path)
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                  Algortihm Ends Here               %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


end