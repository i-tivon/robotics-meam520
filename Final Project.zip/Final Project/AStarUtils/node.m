classdef node
   properties 
      conf
      parent
      H
      G
   end 
end