function equalNode = checkNode(Node1,Node2)
%function to check if 2 nodes are equal within some error
%INPUTS

error=0.01*ones(1,6);
q1=Node1.conf;
q2=Node2.conf;


if all(abs(q1-q2)<error)
    equalNode=1;
else
    equalNode=0;
end







end