function [currentNode,ind] = minNeighb(openSet)
%function that searches the neighbors currently in openSet and finds which
%neighbor has a minimum value of G+H
%
%INPUT
%   openSet - a list or array containing all the configurations currently
%   in neighbor, all elements in openSet are class type node
%
%OUTPUT
%   currentNode - the node with the minimum G+H, which will become the new
%   current node
%   ind - index of currentNode in openSet

s=length(openSet);
Fval=zeros(1,s);
for i=1:s
    %need to normalize all H values to be between 0 and 1 in the set ?
    %for now just keep H as is
    Node=openSet(i);
    %Node.H = somethinggg (maybe normalize based on the dist between ee in
    %zero config and ee in goal)
    %WILL DO THIS WHEN ASSIGNING H ORIGINALLY
    F=Node.G+Node.H;
    Fval(1,i)=F;
    
end
[~,I]=min(Fval);
currentNode=openSet(I);
ind=I;



end