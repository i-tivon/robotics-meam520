function neighb = getNeighbors(currentNode,res,map,robot)
%function to get the neighbors of currentNode
%
%INPUTS
%   currentNode - class type node
%   res - scalar, resolution of the step sizes between configurations
%   map - map of the workspace (to check collisions)
%   robot - robot specs (to check collisions)
%
%OUTPUT
%   neighb - array list of the neighbors whose elements are node types

%neighb=[];
q=currentNode.conf; %configuration (1x6)
th1=q(1); %joints 1-3
th2=q(2);
th3=q(3);
tempNode=node; %temporary node to update
count=1; %counter 

lower=robot.lowerLim;
upper=robot.upperLim;

%cycle through the neighbors
for i=-1:1 %th1
    for j=-1:1 %th2
        for k=-1:1 %th3
            %SHOULD INCLUDE SOMETHING FOR JOINT LIMITS
            tempNode.conf=[th1+res*i, th2+res*j, th3+res*k, q(4), q(5),q(6)];
            tempNode.parent=currentNode;
            %check the configuration doesn't interact with an obstacle
            isCollided = isRobotCollided(tempNode.conf,map,robot);
            %check there isn't a collision between currentNode and tempNode
            %linear interpolation
            % IfNOT collide(qqa)
            %check for collision
            [linePt1,~] = calculateFK_sol(currentNode.conf);
            [linePt2,~] = calculateFK_sol(tempNode.conf);
            obstacles = map.obstacles;
            s = size(map.obstacles);
            qqaCollide = 0;
            for o = 1:s
                c = detectCollision(linePt1, linePt2,obstacles(o,:));
                qqaCollide = qqaCollide | c;  
            end
            
            %if theres no collision in either step, add the node to
            %neighbors
            if isCollided == 0
                if all(qqaCollide)==0
                    neighb(count)=tempNode;
                    if ~(th1>lower(1) && th1<upper(1) && th2>lower(2) && ...
                            th2<upper(2) && th3>lower(3) && th3<upper(3))
                        neighb(count)=[];
                    else
                        count=count+1;
                    end
                end
            end
            
        end
    end
end




end