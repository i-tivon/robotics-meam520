function dist = euclid(current,goal)
%returns the euclidean distance between the end effector in the current
%configuration and the end effector in the goal configuration
%
%INPUTS:
%   current - current configuration, node type
%   goal - goal configuration, node type
%
%OUTPUT:
%   dist - scalar magnitude of the distance between the EE points

qcurr=current.conf;
qgoal=goal.conf;
[posc,~,~]=calculateFK_sol(qcurr);
[posg,~,~]=calculateFK_sol(qgoal);
x1=posc(6,1);
y1=posc(6,2);
z1=posc(6,3);
x2=posg(6,1);
y2=posg(6,2);
z2=posg(6,3);

dist=sqrt((x2-x1)^2+(y2-y1)^2+(z2-z1)^2);

end