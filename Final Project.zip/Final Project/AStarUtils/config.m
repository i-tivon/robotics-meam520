classdef config
   properties 
      val
   end 
end