function member = isMembNode(Node,Set)

s=length(Set);
member=0;
for i=1:s
    if checkNode(Set(i),Node)
        member=1;
        break
    end
end

end