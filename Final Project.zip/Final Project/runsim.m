%% Setup

close all
addpath('utils')
addpath('maps')
addpath('AStarUtils');

profile on

%% Simulation Parameters
%
% Define any additional parameters you may need here. Add the parameters to
% the robot and map structures to pass them to astar or rrt.
%
load 'robot.mat' robot

start = [0,0,0,0,0,0];
goal = [1.4,0,0,0,0,0];

map = loadmap('map3.txt');


%% Run the simulation

% Solve the path problem using A*
[path] = Astar2(map,start,goal,robot);

% OR Solve the path problem using RRT
%[path] = rrt_plus(map,start,goal);

profile off

%% Plot the output

plotLynxPath(map,path,10);

profile viewer
